package api.ega.ega.enums;

public enum Pays {
    BENIN,
    BURKINA_FASO,
    CAP_VERT,
    COTE_DIVOIRE,
    GAMBIE,
    GHANA,
    GUINEE,
    GUINEE_BISSAU,
    LIBERIA,
    MALI,
    MAURITANIE,
    NIGER,
    NIGERIA,
    SENEGAL,
    SIERRA_LEONE,
    TOGO
}

