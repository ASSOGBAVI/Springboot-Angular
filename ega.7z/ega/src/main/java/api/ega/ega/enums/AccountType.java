package api.ega.ega.enums;

public enum AccountType {
    Checking,
    Savings
}
