package api.ega.ega;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EgaApplicationTests {

	@Test
	void contextLoads() {
	}

}
